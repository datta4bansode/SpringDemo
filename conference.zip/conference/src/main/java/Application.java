import com.test.service.ISpakerService;
import com.test.service.SpakerService;

public class Application {
    public static void main(String args[])
    {
        ISpakerService spakerService=new SpakerService();
        System.out.println(spakerService.findAll().get(0).getFirstName());
    }
}
