package com.test.service;

import com.test.model.Speaker;
import com.test.repository.ISpakerRepository;
import com.test.repository.SpakerRepository;

import java.util.List;

public class SpakerService implements ISpakerService {

    private ISpakerRepository spakerRepository=new SpakerRepository();

    @Override
    public List<Speaker> findAll(){
        return spakerRepository.findAll();
    }
}
